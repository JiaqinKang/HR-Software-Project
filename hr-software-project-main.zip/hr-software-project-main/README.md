# HR Software Project 

This is the project repository for our HR Project which is accessible by every group member.


set up dependencies:
npm install cookie-parser express ejs mysql -y










